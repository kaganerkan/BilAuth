from bilauthkaganerkan.bilauth import auth
import bilauthkaganerkan.bilauth as bilauth